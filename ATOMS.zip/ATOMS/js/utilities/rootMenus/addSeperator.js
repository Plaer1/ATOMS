export default function addSeperator() {
    console.log('insertMenuSeperator function called.');

    // Create a new hr element with the desired class names
    const newElement = document.createElement('hr');
    newElement.classList.add('_2jXHP0742MyApMUVUM8IFn', '_21GPYlKBCLsHQpTsHw_RL_');

    // Return the new element
    return newElement;
}