
/*zoom in/out keys:		-must be 1 char
/*Key to zoom in*/
export const zoomInKey = "=";
//Key to zoom out
export const zoomOutKey = "-";

/*birthday for age gate:
/*year*/
export const year = "1969";
//month
export const month = "April";
//day
export const day = "20";

export const filePathPrefix ="skins/ATOMS";

// Millinneum only, makes the colors match system accent color.
export const systemAccentsEnabled ="0";

/* itad api key, public use, will probably get rate limited, get your own here:
https://isthereanydeal.com/apps/my/
per:
https://docs.isthereanydeal.com/#section/Access
*/
export var itadApiKey = 'cd0d6ea01dd4547fa05f63b58696197dab9d3778';